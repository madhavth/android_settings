import 'package:demo_muan_app/main.dart';
import 'package:flutter/material.dart';

class Routes {
  Routes._();
  
  static PageRouteBuilder routeBuilder(RouteSettings settings)
  {
    switch(settings.name)
    {
      case '/':
        return getPageBuilder(child: MyApp());

      default:
        throw UnimplementedError('not implement route ${settings.name}');
    }
  }

  static getPageBuilder({@required Widget child,RouteTransitionsBuilder transit})
  {
    return PageRouteBuilder(
      pageBuilder: (ctx, anim1, anim2) {
        return child;
      },
      transitionsBuilder: transit == null? _defaultTransitionsBuilder : transit 
    );
  }

  static Widget _defaultTransitionsBuilder(BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    return child;
  }
}